var searchData=
[
  ['resident',['resident',['../class_arbor_1_1_state.html#a2ecf03436133ba375376877495f0de7c',1,'Arbor::State']]]
];
