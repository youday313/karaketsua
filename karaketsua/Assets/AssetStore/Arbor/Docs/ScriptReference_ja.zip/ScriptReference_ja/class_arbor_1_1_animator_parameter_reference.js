var class_arbor_1_1_animator_parameter_reference =
[
    [ "animator", "class_arbor_1_1_animator_parameter_reference.html#aa66c4a3f5d581fb71693cfed0eb2dcb6", null ],
    [ "name", "class_arbor_1_1_animator_parameter_reference.html#a8ccf841cb59e451791bcb2e1ac4f1edc", null ],
    [ "type", "class_arbor_1_1_animator_parameter_reference.html#ac765329451135abec74c45e1897abf26", null ]
];